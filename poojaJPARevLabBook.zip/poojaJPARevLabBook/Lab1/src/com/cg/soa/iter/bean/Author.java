package com.cg.soa.iter.bean;

import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Author {
	
	@Id
	
	private int authorid;
	private String firstname;
	private String middlename;
	private String lastname;
	private long phoneno;
	
	public Author() {
		super();
	
	}
	public Author(int authorid, String firstname, String middlename, String lastname, long phoneno) {
		super();
		this.authorid = authorid;
		this.firstname = firstname;
		this.middlename = middlename;
		this.lastname = lastname;
		this.phoneno = phoneno;
	}
	@Override
	public String toString() {
		return "Author [authorid=" + authorid + ", firstname=" + firstname + ", middlename=" + middlename
				+ ", lastname=" + lastname + ", phoneno=" + phoneno + "]";
	}
	public int getauthorid() {
		return authorid;
	}
	public void setauthorid(int authorid) {
		this.authorid = authorid;
	}
	public String getfirstname() {
		return firstname;
	}
	public void setfirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getmiddlename() {
		return middlename;
	}
	public void setmiddlename(String middlename) {
		this.middlename = middlename;
	}
	public String getlastname() {
		return lastname;
	}
	public void setlastname(String lastname) {
		this.lastname = lastname;
	}
	public long getphoneno() {
		return phoneno;
	}
	public void setphoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	
}
