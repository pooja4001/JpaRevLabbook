package com.cg.soa.iter.dao;

import javax.persistence.EntityManager;

import com.cg.soa.iter.bean.Author;
import com.cg.soa.iter.util.JPAUtil;

public class AuthorDaoImpl implements AuthorDao {

	@Override
	public boolean create(Author author) {
		try {
			EntityManager em = JPAUtil.getEntityManager();
			em.getTransaction().begin();
			em.persist(author);
			em.getTransaction().commit();
			return true;
			}catch (Exception e) {
				e.printStackTrace();
			}
			return false;
	}
	@Override
	public Author getauthor(int authorid) {
		Author author=null;
	
		try {
			EntityManager em = JPAUtil.getEntityManager();
			author=em.find(Author.class, authorid);
		}
		catch (Exception e) {
		
		}
		return author;
	}
	@Override
	public boolean update(Author author) {
		try {
			EntityManager em = JPAUtil.getEntityManager();
			em.getTransaction().begin();
			em.merge(author);
			em.getTransaction().commit();
			return true;
			}catch (Exception e) {
				e.printStackTrace();
			}
			return false;
	}
	@Override
	public boolean delete(Author author) {
		try {
		EntityManager em = JPAUtil.getEntityManager();
		em.getTransaction().begin();
		em.remove(author);
		em.getTransaction().commit();
		return true;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return false;
}
}
