package com.cg.soa.iter.service;

import com.cg.soa.iter.bean.Author;

public interface AuthorService {

	boolean create(Author author);

	Author getAuthor(int authorid);

	boolean update(Author author);

	boolean delete(Author author);



}
