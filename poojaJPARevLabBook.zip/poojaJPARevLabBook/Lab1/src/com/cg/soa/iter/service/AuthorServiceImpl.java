package com.cg.soa.iter.service;

import com.cg.soa.iter.bean.Author;
import com.cg.soa.iter.dao.AuthorDao;
import com.cg.soa.iter.dao.AuthorDaoImpl;

public class AuthorServiceImpl implements AuthorService {
	private AuthorDao aDao = new AuthorDaoImpl();

	@Override
	public boolean create(Author author) {
		
		return aDao.create(author);
	}

	@Override
	public Author getAuthor(int authorid) {
		return aDao.getauthor(authorid);
	}

	@Override
	public boolean update(Author author) {
		return aDao.update(author);
	}

	@Override
	public boolean delete(Author author) {
		return aDao.delete(author);
	}


	

	

}
