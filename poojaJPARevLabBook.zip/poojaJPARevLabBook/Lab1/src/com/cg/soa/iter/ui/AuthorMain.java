package com.cg.soa.iter.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.soa.iter.bean.Author;
import com.cg.soa.iter.service.AuthorService;
import com.cg.soa.iter.service.AuthorServiceImpl;


public class AuthorMain {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		AuthorService service = new AuthorServiceImpl();
		int choice=0;
		choice=getChoice(scan);
		switch (choice) {
		case 1:
			System.out.println("Create Author");
			System.out.println("Enter (ID) (First Name) (Middle Name) (Last Name) (Phone Number) ");
			Author author = new Author(scan.nextInt(),scan.next(),scan.next(),scan.next(), scan.nextLong());
			boolean success = service.create(author);
			if(success) 
			{
				System.out.println("Author Created");
			}
			else 
			{
				System.out.println("Author Not Created");
			}
			break;
		case 2:
			System.out.println("Update Author");
			System.out.println("Enter Author Id");
			 author= service.getAuthor(scan.nextInt()) ;
			if(author!=null) {
				System.out.println("Author present ");
				System.out.println("Enter (First Name) (Middle Name) (Last Name) (Phone Number) ");
				author.setfirstname(scan.next());
				author.setmiddlename(scan.next());
				author.setlastname(scan.next());
				author.setphoneno(scan.nextLong());
				boolean success1 = service.update(author);
				if(success1) 
				{
					System.out.println("Author Updated");
				}
				else 
				{
					System.out.println("Author Not Found");
				}
			}
			break;
		case 3:
			System.out.println("Find Author");
			System.out.println("Enter Authorid");
			 author= service.getAuthor(scan.nextInt()) ;
			 if(author!=null)
			 {
					System.out.println("Author found successfully");
				}
				else 
				{
					System.out.println("Author could not be found");
				}
			
			break;
		case 4:
			System.out.println("Delete Author");
			System.out.println("Enter the id to delete");
			author= service.getAuthor(scan.nextInt()) ;
			boolean success2 = service.delete(author);
			if(success2)
			{
				System.out.println("Author Deleted Successfully");
			}else
			{
				System.out.println("Author  could not be deleted");
			}
			break;
		case 5:
			System.out.println("Exiting Program");
			System.exit(0);
			break;

		default:
			System.out.println("Enter 1 to 4 only");
			break;
		}
	}
	

	private static int getChoice(Scanner scan) {
		int choice=0;
		System.out.println("Author");
		System.out.println("1. Create Author");
		System.out.println("2. Update Author");
		System.out.println("3. Find Author");
		System.out.println("4. Delete Author");
		System.out.println("5. Exit Program");
		try {
			choice = scan.nextInt();
			}catch (InputMismatchException e) {
				System.out.println("Please choose a number");
				scan.nextLine();
			}
			return choice;
	
	}

}
