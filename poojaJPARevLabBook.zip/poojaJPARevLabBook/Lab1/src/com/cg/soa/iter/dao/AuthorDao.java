package com.cg.soa.iter.dao;

import com.cg.soa.iter.bean.Author;

public interface AuthorDao {

	boolean create(Author author);
	Author getauthor(int authorid);
	boolean update(Author author);
	boolean delete(Author author);

	

}
